# store/views.py
from django.shortcuts import render, redirect, get_object_or_404
from .models import Product, CartItem  # Make sure both Product and CartItem are imported
from .forms import ProductForm

# Product List View: Display all products on the product list page
def product_list(request):
    products = Product.objects.all()  # Fetch all products from the database
    return render(request, 'store/product_list.html', {'products': products})

# Add Product View: Form to add new products
def add_product(request):
    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            form.save()  # Save the product to the database
            return redirect('product_list')  # Redirect to product list page
    else:
        form = ProductForm()
    
    return render(request, 'store/add_product.html', {'form': form})

# Cart View: Display all cart items and the total price
def cart(request):
    cart_items = CartItem.objects.all()  # Fetch all items in the cart
    total_price = sum(item.total_price() for item in cart_items)  # Calculate total price
    return render(request, 'store/cart.html', {'cart_items': cart_items, 'total_price': total_price})  # Pass data to template


# Add to Cart View: Add a product to the cart
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)  # Find the product
    cart_item, created = CartItem.objects.get_or_create(product=product)  # Add or create cart item
    if not created:
        cart_item.quantity += 1  # If the product is already in the cart, increase the quantity
    cart_item.save()  # Save the cart item
    return redirect('cart')  # Redirect to the cart page

# Update Quantity View: Increase or decrease product quantity in the cart
def update_quantity(request, cart_item_id, action):
    cart_item = get_object_or_404(CartItem, id=cart_item_id)  # Find the cart item
    if action == 'increase':
        cart_item.quantity += 1  # Increase the quantity
    elif action == 'decrease' and cart_item.quantity > 1:
        cart_item.quantity -= 1  # Decrease the quantity, but not below 1
    cart_item.save()  # Save the updated quantity
    return redirect('cart')  # Redirect back to the cart page

# Remove from Cart View: Remove an item from the cart
def remove_from_cart(request, cart_item_id):
    cart_item = get_object_or_404(CartItem, id=cart_item_id)  # Find the cart item to delete
    cart_item.delete()  # Remove the item from the cart
    return redirect('cart')  # Redirect to the cart page after removing

# Checkout View: Placeholder for future checkout functionality
def checkout(request):
    return render(request, 'store/checkout.html')  # Display the checkout page

def update_quantity(request, cart_item_id, action):
    cart_item = get_object_or_404(CartItem, id=cart_item_id)

    if action == 'increase':
        cart_item.quantity += 1
    elif action == 'decrease':
        # Prevent the quantity from going below 1
        if cart_item.quantity > 1:
            cart_item.quantity -= 1
        else:
            # Optionally, you could remove the item if the quantity is 1
            cart_item.delete()
            return redirect('cart')

    cart_item.save()
    return redirect('cart')




def delete_product(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    product.delete()
    return redirect('product_list')  # Change to your product list URL name
