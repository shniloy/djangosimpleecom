from django.urls import path
from . import views
from .views import add_product
from .views import remove_from_cart
from .views import delete_product

urlpatterns = [
    path('', views.product_list, name='product_list'),  # Product list page
    path('cart/', views.cart, name='cart'),  # Cart page (updated view name)
    path('add_to_cart/<int:product_id>/', views.add_to_cart, name='add_to_cart'),  # Add to cart
    path('remove_from_cart/<int:cart_item_id>/', views.remove_from_cart, name='remove_from_cart'),  # Remove from cart
    path('update_quantity/<int:cart_item_id>/<str:action>/', views.update_quantity, name='update_quantity'),  # Update quantity
    path('checkout/', views.checkout, name='checkout'),  # Checkout page (placeholder)
    path('add_product/', views.add_product, name='add_product'),  # Add new product (admin)
    path('product/delete/<int:product_id>/', delete_product, name='delete_product'),
]